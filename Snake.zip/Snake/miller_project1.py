""" Creates a playable version of the game "snake" in dudraw, utilizing a doubly-linked list to store game data.
    File Name: miller_project1
    Author: Maddie Miller
    Date: April 2023
    Course: COMP 1353
    Assignment: Project 1
    Collaborators: COMP 1353 Instructors, COMP 1352 Instructors
    Internet Source: Previous course Canvas page for Vector class, 1353 coursework for Node and DoublyLinkedList classes.
"""

import dudraw
import math
import random
#The Vector class has been imported from last quarter's coursework.
class Vector:
    def __init__(self, some_x=0, some_y=0):
        self.x = some_x
        self.y = some_y

    def limit(self, l):
        if(self.length() >= l):
            self.resize(l)

    def resize(self, l):
        length = math.sqrt(self.x ** 2 + self.y**2)
        self.x *= (l/length)
        self.y *= (l/length)

    def __add__(self, other_vector)->None:
        return Vector(self.x+other_vector.x, self.y + other_vector.y)

    def __sub__(self, other_vector)->None:
        return Vector(self.x-other_vector.x, self.y - other_vector.y)

    def __isub__(self, other_vector)->None:
        self.x -= other_vector.x
        self.y -= other_vector.y
        return self

    def __iadd__(self, other_vector):
        self.x += other_vector.x
        self.y += other_vector.y
        return self

    def divide(self, s):
        self.x /= s
        self.y /= s

    def multiply(self, s):
        self.x *= s
        self.y *= s

    def length(self):
        return math.sqrt(self.x**2 + self.y**2)

    def angle_in_radians(self):
        return math.tan((self.y/self.x))

#The Node and DoublyLinkedList classes have been imported from our previous coursework.
class Node:
    def __init__(self, v, p, n):
        self.value = v
        self.prev = p
        self.next = n
    
    def __str__(self):
       return str(self.value)

class DoublyLinkedList:
   
    def __init__(self):
        self.header = Node(None, None, None)
        self.trailer = Node(None, self.header, None)
        self.header.next = self.trailer
        self.size = 0

    def __str__(self):
        return_str = ''
        self.temp = self.header
        for i in range(self.size + 2):
            if self.temp.value == None:
                pass
            else:
                return_str += (f'{self.temp.value} ')

            if self.temp != self.trailer:
                self.temp = self.temp.next
        return return_str

    def add_between(self, v, n1, n2):
        if n1 is None or n2 is None:
            raise ValueError("n1 and n2 can't be none.")
        if n1.next is not n2:
            raise ValueError("n2 must come before n1.")
        
        new_node = Node(v, n1, n2)
        
        n1.next = new_node
        n2.prev = new_node

        self.size += 1

    def add_first(self, v):
        self.add_between(v, self.header, self.header.next)

    def add_last(self, v):
        self.add_between(v, self.trailer.prev, self.trailer)
    
    def remove_between(self, node1, node2):
        if node1 is None or node2 is None:
            raise ValueError("Cannot use node with no value.")
        
        if node1.next.next is not node2 or node2.prev.prev is not node1:
            raise ValueError("There must be exactly one node between these two nodes.")
        
        removed_node = node1.next
        node1.next = node2
        node2.prev = node1
        
        self.size -= 1
        return removed_node.value
    
    def remove_first(self):
        removed_value = self.remove_between(self.header, self.header.next.next)
        return removed_value

    def remove_last(self):
        removed_value = self.remove_between(self.trailer.prev.prev, self.trailer)
        return removed_value
    
    def search(self, value):
        temp = self.header.next
        for i in range(self.size):
            if temp.value == value:
                return i
            else:
                temp = temp.next
        return -1
    
    def get_size(self):
        return self.size
    
    def first(self):
        return self.header.next.value
    
    def last(self):
        return self.trailer.prev.value
    
    def is_empty(self):
        if self.size == 0:
            return True
        return False
    
    def get(self, index):
        if index < 0 or index > self.size:
            raise ValueError("Index must be between 0 and list size.")
        temp = self.header
        for i in range(index + 1):
            temp = temp.next
        return temp.value
    
    #This function was added to count the number of times a value appears in a DLL, for use in the collision check function below.
    def count(self, value):
        temp = self.header.next
        count = 0
        while temp.value != None:
            if temp.value == value:
                count += 1
        return count
    
class Snake:
    def __init__(self, pos: Vector, vel: Vector, color):
        self.pos = pos
        self.vel = vel
        self.color = color
        self.dll = DoublyLinkedList()

        #Adds 4 segments to the snake, with pos corresponding to the location of the head, and each subsequent segment being in the opposite direction of velocity.
        self.dll.add_first(pos)
        for i in range(3):
            self.dll.add_last(Vector((pos.x + (self.vel.x * (i + 1))), (pos.y + (self.vel.y * (i + 1)))))

    def draw(self):
        dudraw.clear(dudraw.WHITE)
        #Sets the appropriate pen color based on the specified value.
        dudraw.set_pen_color(self.color)

        #This loop draws each square in the list sequentially.
        temp = self.dll.header.next
        while temp.next is not None:
            dudraw.filled_square(temp.value.x, temp.value.y, 0.025)
            temp = temp.next

    def advance(self):
        temp = self.dll.trailer.prev
        #Checks to make sure velocity is not (0,0), and cycles through the dll backwards, assigning each node the value of the "previous" nde.
        if self.vel.x != 0 or self.vel.y != 0:
            while temp.prev != self.dll.header:
                temp.value = temp.prev.value
                temp = temp.prev

            #After all other nodes have been changed, updates the "head" of the snake according to the current velocity.
            temp.value = Vector(temp.value.x + self.vel.x, temp.value.y + self.vel.y)
            self.pos = Vector(round(temp.value.x, 2), round(temp.value.y, 2))

    def add_segment(self):
        #Adds an extra segment of the snake directly behind the last one, in the direction of velocity.
        self.dll.add_last(Vector(self.dll.trailer.prev.value.x + self.vel.x, self.dll.trailer.prev.value.y + self.vel.y))

    def collision_check(self):
        #Checks if the snake collides with a wall, and returns True if so.
        if self.pos.x < 0.05 or self.pos.x > 0.95 or self.pos.y < 0.05 or self.pos.y > 0.95:
            return True
        
        #Checks if the snake collides with itself, and returns True if so.
        head = self.dll.header.next
        temp = self.dll.header.next.next
        while temp.value != None:
            if head.value.x == temp.value.x and head.value.y == temp.value.y:
                return True
            temp = temp.next
        return False

class Food:
    def __init__(self, pos: Vector, color:Vector):
        self.pos = pos
        self.color = color

    def draw(self):
        dudraw.set_pen_color(self.color)
        dudraw.filled_square(self.pos.x, self.pos.y, 0.02)
    
    def is_eaten(self, creature: Snake):
        #Checks if the snake's head overlaps with the position of the fruit, and returns True if it does.
        if self.pos.x == creature.pos.x and self.pos.y == creature.pos.y:
            self.new_food(the_snake)
            return True
        return False
    
    def new_food(self, creature):
        #Places a new fruit at a random location.
        self.pos = Vector(round(random.randrange(1, 19, 1) * 0.05, 2), round(random.randrange(1, 19, 1) * 0.05, 2))

#Generates the snake and the first food pellet at random locations
the_snake = Snake(Vector(round(random.randrange(1, 19, 1) * 0.05, 2), round(random.randrange(1, 19, 1) * 0.05, 2)), Vector(0.05, 0), dudraw.GREEN)
the_food = Food(Vector(round(random.randrange(1, 19, 1) * 0.05, 2), round(random.randrange(1, 19, 1) * 0.05, 2)), dudraw.RED)

dudraw.set_canvas_size(500, 500)
limit = 10 #number of frames to allow to pass before snake moves
timer = 0  #a timer to keep track of number of frames that passed
the_snake.vel = Vector(0, 0) #Sets the snake's velocity to 0 so it is not moving at the start of play.

playing = True
while playing == True:
    timer += 1
    #Changes the snake's velocity based on the most recent key typed
    if dudraw.has_next_key_typed():
        key = dudraw.next_key_typed()
        if key == 'w':
            the_snake.vel = Vector(0, 0.05)
        if key == 'a':
            the_snake.vel = Vector(-0.05, 0)
        if key == 's':
            the_snake.vel = Vector(0, -0.05)
        if key == 'd':
            the_snake.vel = Vector(0.05, 0)

    if timer == limit:
        timer = 0
        the_snake.advance()
        the_snake.draw()
        the_food.draw()
        
        #Checks if snake has eaten food, and adds a segment if true.
        if the_food.is_eaten(the_snake) == True:
            the_snake.add_segment()
        
        #Checks if snake has collided with itself or a wall, and ends the game if true.
        if the_snake.collision_check() == True:
            playing = False

    dudraw.show(40)

dudraw.text(0.5, 0.5, "Game Over")
dudraw.show(10000)