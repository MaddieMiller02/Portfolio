from random import randint

""" Creates a functioning version of malicious hangman in the terminal.
    File Name: miller_project4
    Author: Maddie Miller
    Date: May 2023
    Course: COMP 1353
    Assignment: Project 4, Part 2
    Collaborators: None
    Internet Source: None
"""

#Creates the dictionary of viable words, based on length, for reference later
def create_dictionary():
    words = {}
    with open('Dictionary.txt', 'r') as file:
        for line in file:
            new_word = line.strip()
            if len(new_word) not in words:
                words[len(new_word)] = set()
            words[len(new_word)].add(new_word)
    return words

#This function helps narrow down the answer in the malivious form of hangman.
def generate_answer(possible_answers: list, letter: str):
    return_list = []
    for word in possible_answers:
        if letter not in word:
            return_list.append(word)
    if len(return_list) == 0:
        answer = possible_answers[randint(0, len(possible_answers) - 1)]
        return answer
    else:
         return return_list

#This function implements a normal game of hangman, with the word, word length, and number of guesses being given as input values.
def hangman(possible_answers: list, max_guesses: int, word_length: int):
    guessed_letters = set()
    num_guesses = 0
    player_won = False
    answer = None

    #This list keeps track of how much of the word has been uncovered. It will be printed as a joined string each iteration of the while loop.
    uncovered = []
    for i in range(word_length):
        uncovered.append("_")

    #Prompts the player for a new guess until they have run out of guesses, correctly guessed the word, or uncovered the entire word.
    while num_guesses < max_guesses and player_won == False:
        guess = input(f"So far, you have uncovered {''.join(uncovered)}, and guessed the letters {', '.join(guessed_letters)}. You have {max_guesses - num_guesses} left. What is your guess? ")
        
        #Checks to ensure the player only input letters, and no other characters.
        if guess.isalpha() == False:
            print("That guess contains non-letter characters. Please guess only letters.")

        #This section checks the guess directly against the answer, so long as the guess has more than one character.
        elif len(guess) > 1:

            #Function ends and returns true if the player wins.
            if answer != None:
                if guess == answer:
                    player_won = True
            
            #Marks that the player used a guess if their guess is incorrect.
            else:
                num_guesses += 1
                print("That guess was incorrect.")

        #This section checks to see if a guessed letter is in the answer.
        elif len(guess) == 1:
            letter = guess.lower()[0]

            #Prompts the player to guess again if they guess a letter they've already guessed. 
            if letter in guessed_letters:
                print("You already guessed that letter! Try again.")

            #Checks if a guessed letter is in the answer, adds it to the guessed_letter set, and marks that thep layer used a guess.
            else:
                guessed_letters.add(letter)
                num_guesses += 1

                #This section only runs if a specific answer has been determined from the list of possible answers.
                if answer != None:

                    #Correct guess
                    if letter in answer:
                    
                        #Updates the list of uncovered letters to include the guessed letter in the appropriate places.
                        for i in range(len(answer)):
                            if answer[i] == letter:
                                uncovered[i] = letter

                        print("That letter is in the answer!")

                    #Incorrect guess
                    else:
                        print("That letter isn't in the answer.")

                    #Checks if the player has uncovered the entire word, and indicates if so.
                    if ''.join(uncovered) == answer:
                        player_won = True
                
                #This section generates the answer or narrows down the possible answers using the generate_answer function.
                else:
                    generated = generate_answer(possible_answers, guess)                   
                    if type(generated) == str:
                        answer = generated
                        
                        if guess in answer:
                            for i in range(len(answer)):
                                if answer[i] == letter:
                                    uncovered[i] = letter

                            print("That letter is in the answer!")
                        
                        else:
                            print("That letter isn't in the answer.")
                        
                    else:
                        possible_answers = generated
                        print("That letter isn't in the answer.")

    if player_won == True:
        print(f'Congratulations! The answer was {answer}! You won!')
    else:
        print(f'Sorry... You lost. The answer was {answer}.')
                

#Main code block
words = create_dictionary()
print("Welcome to hangman!")
keep_playing = True
while keep_playing == True:

    #Prompts the player for the desired length of the answer.
    num_characters = input("How many letters long should the answer be? ")
    while num_characters.isnumeric() == False:
        print("This must be a number.")
        num_characters = input("How many letters long should the answer be? ")
    num_characters = int(num_characters)

    #Prompts the player for the desired number of guesses.
    max_guesses = input("How many guesses would you like? ")
    while max_guesses.isnumeric() == False:
        print("This must be a number.")
        max_guesses = input("How many guesses would you like? ")
    max_guesses = int(max_guesses)
    
    #Makes the possible answers its own list that can be pulled from.
    possible_answers = words[num_characters]

    #Runs the hangman game with the given parameters.
    hangman(possible_answers, max_guesses, num_characters)

    #Asks the player if they'd like to continue playing.
    yes_or_no = input("Would you like to keep playing? ")
    while yes_or_no.lower() != "yes" and yes_or_no.lower() != "no":
        print("Answer must be 'yes' or 'no.'")
        yes_or_no = input("Would you like to keep playing? ")

    if yes_or_no.lower() == "yes":
        keep_playing = True
    if yes_or_no.lower() == "no":
        keep_playing = False
